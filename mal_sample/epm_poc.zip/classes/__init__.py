import os

SMTP_SERVER = "10.250.230.170"
ROOT_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
MAL_SPL_DIR = os.path.join(ROOT_DIR, "mal_sample")